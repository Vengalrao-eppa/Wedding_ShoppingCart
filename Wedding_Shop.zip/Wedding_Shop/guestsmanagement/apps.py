from django.apps import AppConfig


class GuestsmanagementConfig(AppConfig):
    name = 'guestsmanagement'
